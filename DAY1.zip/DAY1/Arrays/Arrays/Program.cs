﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Arrays
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string[] arr = { "Yash", "Amey", "Nihal", "Shreepad", "Sahil" }; 
           
            Console.WriteLine("Enter name to be searched");
            var match = Console.ReadLine();
            if (arr.Contains(match))
            {
                Console.WriteLine("It contains " + match);
            }
            else
            {
                Console.WriteLine("The name is not present");
            }

            Console.ReadLine();
           OddEven();
            SearchLetter();
               
            

        }
       
       static void OddEven()
        {
            string[] arr = { "Yash", "Amey", "Nihal", "Shreepad", "Sahil" };
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Length %2 != 0)
                {
                    Console.WriteLine(arr[i] + " is Odd");
                }
                
            }
            Console.ReadLine();
        }

        static void SearchLetter()
        {
            string[] arr = { "Yash", "Amey", "Nihal", "Shreepad", "Sahil", "Zende","Munot" };
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Contains("a"))
                {
                    Console.WriteLine("String containing a letter is: " +arr[i]);
                }
            }
            Console.ReadLine();
        }

    }
}
