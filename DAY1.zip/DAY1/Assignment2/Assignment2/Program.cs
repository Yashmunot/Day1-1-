﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
     class Program
        {
            static void Main(string[] args)
            {
                child c = new child();
                Console.WriteLine(c.sub(10, 5));
            }
        }

        abstract class parent
        {
            protected abstract int sub(int a, int b);
        }

        abstract class child : parent
        {
            protected override int sub(int a, int b)
            {
                return a - b;
            }
        }
    }
