﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Transaction amount...");
            double transamount = Convert.ToInt32(Console.ReadLine());
            Bank b = new Bank(transamount);
            Thread t1 = new Thread(b.deposit);
            Thread t2 = new Thread(b.withdrawal);
            Console.WriteLine("Deposit OR withdrawal");
           
            string no = Console.ReadLine();
            if (no == "Deposit" | no =="deposit")
            {
                Console.WriteLine("Amount afer Deposit");
                t1.Start();
            }
            else if (no == "withdrawal" | no == "Withdrawal" )
            {
                Console.WriteLine("");
                Console.WriteLine("Amount after Withdrawal");
                t2.Start();
            }
            else
            {
                Console.WriteLine("Error");
            }

            Console.ReadLine();

        }
    }
}
        
    

