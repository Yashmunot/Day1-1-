﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

 

namespace Assignment4_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch;
            Stack<string> astk = new Stack<string>();
            Stack<string> bstk = new Stack<string>();

            Console.WriteLine("1. Push");
            Console.WriteLine("2. Pop");
            Console.WriteLine("3. Search");
            Console.WriteLine("4. Reverse");
            Console.WriteLine("5. Display Stack");
            Console.WriteLine("6. Exit");

            do
            {
                Console.WriteLine("Select the operation you want to perform");
                ch = Convert.ToInt32(Console.ReadLine());




                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Add element");
                        string user = Console.ReadLine();
                        astk.Push(user);
                        Console.WriteLine("Element added");
                        foreach (string x in astk)
                        {
                            Console.WriteLine(x);
                        }
                        break;



                    case 2:
                        if (astk == null)
                        {
                            Console.WriteLine("Error: Stack empty");
                        }
                        else
                        {
                            astk.Pop();
                            Console.WriteLine("Element Removed!!");
                        }
                        break;




                    case 3:
                        Console.WriteLine("");
                        Console.WriteLine("Enter element to be searched");
                        string user1 = Console.ReadLine();
                        if (astk.Contains(user1))
                        {
                            Console.WriteLine("Element Found!!");
                        }
                        else
                        {
                            Console.WriteLine("Element Absent!!");
                        }
                        break;



                    case 4:
                        Console.WriteLine("");



                        while (astk.Count != 0)
                        {
                            bstk.Push(astk.Pop());
                        }
                        Console.WriteLine("\nReversed Stack");
                        foreach (object x in bstk)
                        {
                            Console.WriteLine(x + " ");
                        }
                        break;



                    case 5:
                        Console.WriteLine("");
                        Console.WriteLine("Elements are: ");
                        foreach (string x in astk)
                        {
                            Console.WriteLine(x + " ");
                        }
                        break;



                }
            } while (ch != 6);



        }
    }
}